Thank you for downloading Nallian Galaxies! Before you launch the game, please consider the following:
 - This is an closed-alpha build, do not share, upload or redistribute this game. You must ask for permission from the developers to take a screenshot or upload a gameplay video.
 - Nallian Galaxies is still in *very* early development and therefor, this build may not accuratly represent the whole game.
